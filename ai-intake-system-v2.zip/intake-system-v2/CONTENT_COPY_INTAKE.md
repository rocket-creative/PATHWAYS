# Content & Copy Intake Questionnaire
## UXUI Design Corp Edition

Complete this questionnaire to generate a `content-copy.mdc` file for the project.

**Note:** Items marked with 🔒 are UXUI Design Corp or Rocket Creative standards (non-negotiable). Items marked with 💡 are suggested defaults.

---

## Section 1: Industry Context

🔒 **REQUIRED: Industry must be identified first (see PROJECT_INTAKE.md Section 0).**

**Project industry:**
> [ ] Biotech/Life Sciences
> [ ] Healthcare/Medical
> [ ] Luxury Services/Hospitality
> [ ] Financial Services
> [ ] Legal
> [ ] E-commerce/Retail
> [ ] SaaS/Technology
> [ ] Other: _______________

---

## Section 2: Brand Voice

### 2.1 Voice Attributes

**Select 3-5 attributes that describe the brand voice:**

> [ ] Professional
> [ ] Friendly
> [ ] Authoritative 💡 (biotech/healthcare)
> [ ] Approachable
> [ ] Technical
> [ ] Simple
> [ ] Playful
> [ ] Serious
> [ ] Warm
> [ ] Direct 💡 (Rocket Creative standard)
> [ ] Sophisticated 💡 (luxury)
> [ ] Casual
> [ ] Confident
> [ ] Elegant
> [ ] Other: _______________

---

### 2.2 Industry Voice Defaults

🔒 **Apply industry appropriate voice:**

**Biotech/Healthcare:**
- Authoritative but accessible
- Scientific credibility
- Translate complex to simple
- Progressive disclosure (simple overview → detailed science)
- Avoid jargon in primary messaging

**Luxury/Hospitality:**
- Elegant, refined
- Restraint signals confidence
- Every word serves a purpose
- Show, don't tell
- Immersive, not salesy

**Financial Services:**
- Trustworthy, stable
- Clear, transparent
- No exaggeration

**Legal:**
- Credible, authoritative
- Clear practice areas
- Credentials emphasized

---

### 2.3 Voice Description

**In one sentence, how should the brand sound?**
> 

**What should the brand NEVER sound like?**
> 

---

## Section 3: Tone Variations

### 3.1 Tone by Context

| Context | Tone |
|---------|------|
| Homepage/marketing | |
| Product UI | |
| Onboarding | |
| Error messages | |
| Success messages | |
| Help/support | |
| Email (transactional) | |
| Email (marketing) | |

---

## Section 4: Writing Style

### 4.1 Grammar & Punctuation

**Sentence structure:**
> [ ] Short, punchy 💡
> [ ] Mix of lengths
> [ ] Longer, flowing

**Voice:**
> [ ] Active voice required 💡
> [ ] Active preferred
> [ ] No preference

**Contractions:**
> [ ] Always use (casual)
> [ ] Context dependent 💡
> [ ] Avoid (formal)

---

### 4.2 Punctuation Rules

🔒 **FIXED (Rocket Creative projects): No hyphens in copy.**

**Hyphens:**
> [ ] 🔒 FORBIDDEN — rewrite to avoid (Rocket Creative standard)
> [ ] Minimize
> [ ] Standard usage

**Oxford comma:**
> [ ] Always use 💡
> [ ] Never use
> [ ] No preference

**Exclamation points:**
> [ ] Sparingly (1 per page max) 💡
> [ ] Avoid entirely
> [ ] Use freely

**Em dashes:**
> [ ] Allowed
> [ ] Avoid, rewrite sentences 💡
> [ ] No preference

---

### 4.3 Formatting

**Heading case:**
> [ ] Sentence case 💡 (Only first word capitalized)
> [ ] Title Case
> [ ] ALL CAPS (specific contexts only)

**Numbers:**
> [ ] Spell out 1-9, numerals 10+ 💡
> [ ] Spell out 1-10
> [ ] Always numerals

---

## Section 5: Terminology

### 5.1 Industry Terminology

🔒 **REQUIRED: Define industry specific terms.**

**Biotech/Healthcare examples:**
- Use researcher friendly terminology
- Scientific accuracy over marketing language
- Cite sources for claims

**Luxury examples:**
- Elevated vocabulary
- Avoid common/generic words

| Term | Correct usage | Never say |
|------|---------------|-----------|
|      |               |           |
|      |               |           |
|      |               |           |

---

### 5.2 Product Terminology

**Product name (exact spelling):**
> 

**What do you call users?**
> [ ] Users
> [ ] Customers
> [ ] Members
> [ ] Clients
> [ ] [Industry specific]: _______________

---

### 5.3 Forbidden Words & Phrases

🔒 **FIXED: Common clichés to avoid:**

- [ ] "Leverage"
- [ ] "Synergy"
- [ ] "Best in class"
- [ ] "Cutting edge"
- [ ] "Revolutionary"
- [ ] "Game changing"
- [ ] "Seamless"
- [ ] "Robust"
- [ ] "Empower"

**Project specific forbidden words:**

| Word/Phrase | Reason | Use instead |
|-------------|--------|-------------|
|             |        |             |
|             |        |             |

---

### 5.4 Preferred Alternatives

| Instead of | Use |
|------------|-----|
|            |     |
|            |     |

---

## Section 6: SEO & Content Structure

### 6.1 SEO Rules

🔒 **FIXED: Meta keywords tag is OBSOLETE. Never include.**

**What actually matters:**
- Title tags (60 chars max, keyword at beginning)
- Meta descriptions (155-160 chars, compelling CTAs)
- Schema.org structured data
- Header hierarchy (H1-H6)
- Alt text (descriptive, keyword relevant)

---

### 6.2 Content Structure Rules

🔒 **FIXED: SEO structure requirements:**

**Title tags:**
- 60 characters maximum
- Primary keyword at beginning
- Brand name at end

**Meta descriptions:**
- 155-160 characters
- Compelling CTA
- Natural keyword inclusion

**H1:**
- One per page
- Primary keyword included
- Under 60 characters

**URL structure:**
- Lowercase only
- Hyphens between words (URLs only, not copy)
- Short and descriptive
- No unnecessary parameters

---

### 6.3 Keywords

**Primary keywords:**
- 
- 
- 

**Secondary keywords:**
- 
- 
- 

---

### 6.4 Content Types

**Blog/Articles:**
> Target length: 
> Required elements: 

**Landing pages:**
> Key sections: 
> CTA requirements: 

**Service pages:**
> Required elements: 

---

## Section 7: Industry Content Approaches

🔒 **Apply industry specific content rules:**

### Biotech/Healthcare

**Content approach:**
- Translate complex science into accessible language
- Avoid jargon in primary messaging
- Progressive disclosure: simple overview → detailed science
- Video explanations for mechanisms of action
- Data visualization over dense text
- Cite sources for scientific claims

**Required elements:**
- Team bios with credentials
- Third party validation (partnerships, grants, publications)
- Compliance mentions (FDA, regulatory approvals)

---

### Luxury/Hospitality

**Content approach:**
- Elegance over information density
- Every element serves a purpose
- Restraint signals confidence
- Visual storytelling through lifestyle imagery
- Immersive experiences, not sales pitches

**Avoid:**
- Information overload
- Hard selling language
- Common/generic words

---

### Financial Services

**Content approach:**
- Transparent pricing
- Certifications displayed
- Encryption/security details visible
- Trust indicators prominent

---

### Legal

**Content approach:**
- Clear practice areas
- Credentials prominently displayed
- Case results (where permitted)
- Testimonials with proper attribution

---

## Section 8: Accessibility & Inclusion

### 8.1 Inclusive Language

🔒 **FIXED: Inclusive language required.**

**Gender neutral:**
> [ ] Required (they/them, avoid gendered terms) 💡
> [ ] Preferred
> [ ] No specific requirement

**Ableist language to avoid:**
- "Crazy," "insane"
- "Blind spot"
- "Fall on deaf ears"
- "Lame"

---

### 8.2 Reading Level

**Target reading level:**
> [ ] 6th grade (simple)
> [ ] 8th grade (general) 💡
> [ ] 10th grade (educated)
> [ ] 12th grade+ (expert)

---

### 8.3 Alt Text

🔒 **FIXED: Alt text requirements:**

- All images require alt text
- Decorative images use empty alt=""
- Describe function, not just appearance
- Include keywords when natural
- 125 characters maximum

---

## Section 9: Legal Content

### 9.1 Required Disclaimers

🔒 **FIXED: Industry specific legal content required.**

After industry identification, AI must research:
- `[industry] privacy policy requirements 2025`
- `[industry] terms of service best practices`
- `[industry] legal compliance regulations`

**Industry specific clauses needed:**

| Industry | Required clauses |
|----------|-----------------|
| Healthcare | HIPAA, PHI handling, medical data protection |
| Financial | PCI compliance, banking regulations |
| Legal | Attorney client privilege, confidentiality |
| E-commerce | Consumer protection, return policies |
| SaaS | Data processing, international transfers |
| Education | FERPA, student data protection |
| Biotech | Research data, clinical trials, regulatory |

---

### 9.2 Claims & Substantiation

**Can make claims about:**
> [ ] Product features (factual)
> [ ] Customer results (substantiated)
> [ ] Awards (verified)

**Superlatives policy:**
> [ ] Avoid ("best," "fastest") 💡
> [ ] Use with qualification
> [ ] Use if substantiated

---

### 9.3 Competitor Mentions

**Policy:**
> [ ] Never mention by name 💡
> [ ] Comparative claims if factual
> [ ] Industry comparisons only

---

## Section 10: AI Readability

🔒 **FIXED: Content structure for AI parsing:**

**Required:**
- Proper semantic HTML (header, nav, main, article, section, footer)
- Clear, descriptive headings
- Paragraphs 3-4 sentences max
- Proper heading hierarchy (never skip levels)
- ARIA landmarks for major sections
- `lang` attribute on html tag

---

## Section 11: Examples

### 11.1 Good Examples

**Copy that represents the ideal voice:**

> Example 1:
> Source:
> Why it works:

> Example 2:
> Source:
> Why it works:

---

### 11.2 Bad Examples

**Copy that does NOT represent the voice:**

> Example 1:
> What's wrong:

---

## Section 12: Quick Reference Summary

After completing intake, generate:

- [ ] Voice summary (2-3 sentences)
- [ ] Tone chart by context
- [ ] Do/don't list
- [ ] Terminology glossary
- [ ] Forbidden words list
- [ ] Industry specific rules

---

## Notes

> 

---

## Intake Completed

**Completed by:**
> 

**Date:**
> 

**Industry:**
> 

**No hyphens rule applies:**
> [ ] Yes (Rocket Creative project)
> [ ] No

---

*UXUI Design Corp + Rocket Creative standards embedded. Version 2.0*
