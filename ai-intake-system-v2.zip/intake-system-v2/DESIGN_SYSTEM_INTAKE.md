# Design System Intake Questionnaire
## UXUI Design Corp Edition

Complete this questionnaire to generate a `design-system.mdc` file for the project.

**Note:** Items marked with 🔒 are UXUI Design Corp standards and should not be changed without explicit justification. Items marked with 💡 are suggested defaults.

---

## Section 1: Foundation

### 1.1 Design Source of Truth

**Where do designs live?**
> [ ] Figma 💡
> [ ] Sketch
> [ ] Adobe XD
> [ ] No design tool (code first)
> [ ] Other: _______________

**Design file URL:**
> 

**Who maintains the designs?**
> Name/role: 

**Design-to-code workflow:**
> [ ] Designer hands off, developer implements
> [ ] Designer and developer collaborate in real time 💡
> [ ] Developer drives, designer reviews
> [ ] No designer (developer owns design)

---

### 1.2 Industry Context

🔒 **REQUIRED: Industry must be identified before design work begins.**

**Project industry:**
> [ ] Biotech/Life Sciences
> [ ] Healthcare/Medical
> [ ] Luxury Services/Hospitality
> [ ] Financial Services
> [ ] Legal
> [ ] E-commerce/Retail
> [ ] SaaS/Technology
> [ ] Real Estate
> [ ] Creative/Media
> [ ] Other: _______________

**Industry research completed?**
> [ ] Color palette research done
> [ ] Typography standards identified
> [ ] Competitor analysis completed
> [ ] Industry compliance requirements noted

---

### 1.3 Brand Guidelines

**Brand guidelines document:**
> [ ] Exists, URL: _______________
> [ ] Exists, needs to be shared
> [ ] Does not exist
> [ ] In progress

**Logo files provided?**
> [ ] Yes, SVG 💡
> [ ] Yes, PNG only
> [ ] Yes, multiple formats
> [ ] Not yet

---

## Section 2: Color System

### 2.1 Industry Color Palettes

🔒 **Use industry appropriate colors. Reference these defaults:**

**Biotech/Healthcare:**
- Primary: Blues (#1C2541, #2563EB) for trust
- Secondary: Whites, light grays for clean aesthetic
- Accents: Purple (#6B46C1) for innovation, muted greens
- ❌ Avoid: Bright reds, yellows (warning associations)

**Luxury/Hospitality:**
- Foundation: Black (#000000) and white (#FFFFFF)
- Metallics: Gold (#D4AF37, #C9B037), rose gold
- Jewel tones: Deep navy (#1C2541), burgundy, emerald
- Warm neutrals: Mocha, taupe, cream
- Limit: 2-3 colors maximum

**Financial Services:**
- Primary: Navy blue, dark green, grays
- Signal: Trust and stability

**Legal:**
- Primary: Navy, burgundy
- Accents: Gold for authority

---

### 2.2 Project Colors

**Primary brand color:**
> Hex: #
> Name: 

**Secondary brand color(s):**

| Name | Hex |
|------|-----|
|      | #   |
|      | #   |

**Accent color(s):**

| Name | Hex |
|------|-----|
|      | #   |

---

### 2.3 Semantic Colors

| Function | Light mode | Dark mode (if applicable) |
|----------|------------|---------------------------|
| Background (primary) | # | # |
| Background (secondary) | # | # |
| Text (primary) | # | # |
| Text (secondary) | # | # |
| Border (default) | # | # |

**Feedback colors:**

| State | Color |
|-------|-------|
| Success | # |
| Warning | # |
| Error | # |
| Info | # |

---

### 2.4 Color Accessibility

🔒 **FIXED: WCAG 2.1 AA minimum required.**

- Text contrast: 4.5:1 minimum (normal text)
- Large text contrast: 3:1 minimum (18pt+)
- Never rely on color alone for information

**Colors tested for contrast?**
> [ ] Yes, all pass
> [ ] Yes, issues identified
> [ ] No, needs testing

---

## Section 3: Typography

### 3.1 Industry Typography Defaults

🔒 **Use industry appropriate typography:**

**Biotech/Healthcare:**
- Sans-serif primary: Inter, Roboto, Source Sans Pro 💡
- Serif accents: Playfair Display (sparingly)
- Minimum body: 16px

**Luxury/Hospitality:**
- Serif dominates: Didot, Bodoni, Garamond, Playfair Display
- Light weights with generous letter spacing
- Sans-serif support: Avenir, Lato

**Financial/Legal:**
- Serif for tradition and credibility
- Clean sans-serif for modern fintech

---

### 3.2 Font Families

**Primary font (body):**
> Name: 
> Source: [ ] Google Fonts 💡 [ ] Adobe Fonts [ ] Self-hosted [ ] System
> Weights: [ ] 300 [ ] 400 💡 [ ] 500 [ ] 600 [ ] 700 💡 [ ] 800 [ ] 900

**Secondary font (headings, if different):**
> Name: 
> Source: [ ] Google Fonts [ ] Adobe Fonts [ ] Self-hosted [ ] System
> Weights: [ ] 300 [ ] 400 [ ] 500 [ ] 600 [ ] 700 [ ] 800 [ ] 900

**Monospace font:**
> [ ] System default 💡
> [ ] Custom: _______________

---

### 3.3 Type Scale

🔒 **FIXED: Base font size 16px minimum for accessibility.**

**Base font size:**
> [ ] 16px 🔒 DEFAULT
> [ ] 18px
> [ ] Other (must justify): _______________

**Scale ratio:**
> [ ] 1.200 (Minor Third)
> [ ] 1.250 (Major Third) 💡
> [ ] 1.333 (Perfect Fourth)
> [ ] Custom: _______________

🔒 **FIXED: Use fluid typography with clamp():**

```css
h1: clamp(2rem, 5vw, 3.5rem)
h2: clamp(1.5rem, 4vw, 2.5rem)
p: clamp(1rem, 2vw, 1.125rem)
```

---

### 3.4 Text Styling

**Maximum line length:**
> [ ] 65 characters 💡
> [ ] 75 characters
> [ ] Other: _______________

**Line height:**
> Headings: 1.2 💡
> Body: 1.6 💡

---

## Section 4: Layout & Spacing

### 4.1 Maximum Width Constraint

🔒 **FIXED: 1440px maximum content width.**

This is a UXUI Design Corp standard for optimal readability on large monitors (32"+). Content centers on larger displays, never stretches full width.

**Implementation:**
```css
.container {
  max-width: 1440px;
  margin: 0 auto;
}
```

**Testing required:**
- [ ] 1920x1080 (content centered)
- [ ] 2560x1440 (content centered at 1440px)
- [ ] 3840x2160 4K (content centered)

---

### 4.2 Responsive Padding

🔒 **FIXED: Mobile first responsive padding:**

| Breakpoint | Padding |
|------------|---------|
| Mobile (base) | 16px (1rem) |
| 640px+ | 24px (1.5rem) |
| 1024px+ | 32px (2rem) |
| 1440px+ | 48px (3rem) |

---

### 4.3 Breakpoints

🔒 **FIXED: Tailwind breakpoints modified for 1440px constraint:**

| Name | Value | Notes |
|------|-------|-------|
| sm | 640px | Small tablets |
| md | 768px | Tablets |
| lg | 1024px | Small laptops |
| xl | 1280px | Desktops |
| 2xl | 1440px | 🔒 Maximum (modified from Tailwind default) |

```javascript
// tailwind.config.js
screens: {
  'sm': '640px',
  'md': '768px',
  'lg': '1024px',
  'xl': '1280px',
  '2xl': '1440px', // Modified to match 1440px max
}
```

---

### 4.4 Spacing Scale

**Base unit:**
> [ ] 4px 💡
> [ ] 8px
> [ ] Other: _______________

**Custom spacing tokens (if needed):**

| Token | Value | Use case |
|-------|-------|----------|
| xs | | |
| sm | | |
| md | | |
| lg | | |
| xl | | |

---

## Section 5: Components

### 5.1 Component Naming

🔒 **FIXED: All custom components use |UXUIDC| prefix.**

```
components/
  |UXUIDC|/
    Navigation.tsx
    Footer.tsx
    HeroSection.tsx
    AnnouncementBar.tsx
    ImagePlaceholder.tsx
    CookieConsent.tsx
    ConstrainedLayout.tsx

lib/
  |UXUIDC|/
    animations.ts
    gsap-utils.ts
```

---

### 5.2 Component Library Base

**Base component library:**
> [ ] shadcn/ui 💡
> [ ] Radix UI
> [ ] Headless UI
> [ ] Custom only
> [ ] Other: _______________

---

### 5.3 Shadow System

🔒 **FIXED: No colored shadows. Neutral shadows only.**

```css
--shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
--shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
--shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
--shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);

/* ❌ FORBIDDEN: Colored shadows like: */
/* box-shadow: 0 4px 6px rgb(59 130 246 / 0.5); */
```

---

### 5.4 Border Radius

**Border radius scale:**

| Token | Value |
|-------|-------|
| none | 0 |
| sm | |
| md | 💡 default |
| lg | |
| full | 9999px |

---

### 5.5 Image Placeholders

🔒 **FIXED: Use outlined div placeholders during development.**

```tsx
// |UXUIDC|ImagePlaceholder component required
<div className="border-2 border-dashed border-gray-300 bg-gray-50">
  <span className="text-gray-400">Image</span>
</div>
```

**Aspect ratios supported:**
- 16/9 (default)
- 4/3
- 1/1
- 3/2

---

## Section 6: Navigation & Footer

### 6.1 Navigation Requirements

🔒 **FIXED: |UXUIDC|Navigation component requirements:**

- [ ] Fluid GSAP animations
- [ ] Mobile hamburger menu
- [ ] Desktop horizontal menu
- [ ] Search functionality
- [ ] Keyboard accessible
- [ ] Scroll triggered background change
- [ ] Constrained to 1440px max width

---

### 6.2 Footer Requirements

🔒 **FIXED: |UXUIDC|Footer component requirements:**

- [ ] Constrained to 1440px max width
- [ ] Legal links section (Privacy, Terms, Cookies, Accessibility)
- [ ] Social media links
- [ ] Copyright with "Built by UXUI Design Corp"
- [ ] Keyboard accessible

---

## Section 7: Animation System

### 7.1 Animation Library

🔒 **FIXED: GSAP for all animations.**

```bash
npm install gsap
```

**Required plugins:**
- ScrollTrigger
- ScrollToPlugin

---

### 7.2 Animation Patterns

🔒 **FIXED: Standard animation components:**

| Component | Purpose |
|-----------|---------|
| |UXUIDC|FadeInScroll | Fade in on scroll |
| |UXUIDC|StaggerAnimation | Staggered reveal |
| |UXUIDC|ParallaxEffect | Parallax scrolling |
| |UXUIDC|AnnouncementBar | Horizontal scroll |
| |UXUIDC|VerticalImageScroll | Vertical image scroll |

---

### 7.3 Animation Performance

🔒 **FIXED: Animation performance rules:**

- Animate only `transform` and `opacity` (GPU accelerated)
- Use `will-change: transform` sparingly
- Never animate layout properties (width, height, margin)
- Always cleanup animations in useEffect return
- Respect `prefers-reduced-motion`

---

### 7.4 Animation Timing

**Default duration:**
> [ ] 0.3s (fast) 💡 for micro interactions
> [ ] 0.6s (normal) 💡 for reveals
> [ ] 1s (slow) for page transitions

**Default easing:**
> [ ] power2.out 💡
> [ ] power2.inOut
> [ ] Custom: _______________

---

## Section 8: Legal Pages

🔒 **FIXED: Required legal pages for every project:**

| Page | Path | Required |
|------|------|----------|
| Privacy Policy | /privacy | 🔒 YES |
| Terms of Service | /terms | 🔒 YES |
| Cookie Policy | /cookies | 🔒 YES |
| Accessibility Statement | /accessibility | 🔒 YES |

---

### 8.1 Cookie Consent

🔒 **FIXED: |UXUIDC|CookieConsent component required.**

**Consent categories:**
- Necessary (always on)
- Analytics (opt in)
- Marketing (opt in)
- Functional (opt in)

**Features:**
- Granular category selection
- Preference center accessible anytime
- Equal prominence Accept/Reject buttons
- No dark patterns
- GPC signal respected

---

## Section 9: Industry Specific Overrides

Based on the industry selected in Section 1.2, apply these overrides:

### Biotech/Healthcare

**Layout principles:**
- Scientific credibility through clean design
- High quality imagery (lab, microscopy, facilities)
- Clear audience pathways (investors, researchers, patients)
- Team bios with credentials
- Third party validation (partnerships, grants)
- Compliance mentions (FDA, regulatory)

**Content approach:**
- Translate complex science to accessible language
- Progressive disclosure (simple → detailed)
- Data visualization over dense text

---

### Luxury/Hospitality

**Layout principles:**
- Generous white space (60%+ of page)
- Minimalist, uncluttered layouts
- High resolution photography (minimum 2000px)
- Cinematic video backgrounds (slow pacing)
- Smooth parallax, subtle hover states
- Intentional animations (never decorative)

**Content approach:**
- Elegance over information density
- Every element serves a purpose
- Visual storytelling through lifestyle imagery

---

### Financial Services

**Layout principles:**
- Clear data presentation
- Security badges visible
- Compliance information accessible

**Content approach:**
- Transparent pricing
- Certifications displayed
- Encryption details visible

---

### Legal

**Layout principles:**
- Attorney profiles prominent
- Case results displayed
- Credentials visible

**Content approach:**
- Clear practice areas
- Credentials emphasized
- Testimonials with attribution

---

## Section 10: Dark Mode

### 10.1 Dark Mode Strategy

**Dark mode support:**
> [ ] Not needed
> [ ] System preference only
> [ ] User toggle only
> [ ] Both system + toggle
> [ ] Dark mode is default

**If supported, define color overrides in Section 2.3.**

---

## Section 11: SEO & Meta

🔒 **FIXED: Meta keywords tag is OBSOLETE. Do not include.**

**Required meta tags:**
- Title (60 chars max, keyword at beginning)
- Description (155-160 chars)
- Open Graph tags
- Twitter Card tags
- Schema.org structured data

**OG image dimensions:**
- Facebook/LinkedIn: 1200x630px
- Twitter: 1200x675px

---

## Section 12: Checklist

### Pre-Development
- [ ] Industry identified
- [ ] Industry design standards researched
- [ ] Color palette confirmed
- [ ] Typography confirmed
- [ ] 1440px constraint understood

### During Development
- [ ] |UXUIDC| naming convention used
- [ ] No colored shadows
- [ ] 1440px max-width applied
- [ ] Semantic HTML used
- [ ] ARIA labels added
- [ ] Keyboard navigation tested

### Pre-Launch
- [ ] Lighthouse 90+ all metrics
- [ ] Legal pages created
- [ ] Cookie consent working
- [ ] Large display testing complete
- [ ] Accessibility audit passed

---

## Notes & Deviations

**If deviating from any 🔒 FIXED standard, document here:**

| Standard | Deviation | Justification | Approved by |
|----------|-----------|---------------|-------------|
|          |           |               |             |

---

## Intake Completed

**Completed by:**
> 

**Date:**
> 

**Industry:**
> 

---

*UXUI Design Corp standards embedded. Deviations require documentation.*
