# UXUI Design Corp Fixed Standards

This document lists all non-negotiable standards that apply to every UXUI Design Corp project. These are baked into the intake system and should never be overridden without documented justification.

---

## Layout Standards

### 1440px Maximum Width
**Status:** 🔒 FIXED

All content constrained to 1440px maximum width for optimal readability on large monitors. Content centers on displays larger than 1440px.

```css
.container {
  max-width: 1440px;
  margin: 0 auto;
}
```

**Testing required:**
- 1920x1080 displays
- 2560x1440 displays
- 3840x2160 (4K) displays

---

### Responsive Padding
**Status:** 🔒 FIXED

| Breakpoint | Padding |
|------------|---------|
| Mobile | 16px (1rem) |
| 640px+ | 24px (1.5rem) |
| 1024px+ | 32px (2rem) |
| 1440px+ | 48px (3rem) |

---

### Breakpoints (Tailwind Modified)
**Status:** 🔒 FIXED

```javascript
screens: {
  'sm': '640px',
  'md': '768px',
  'lg': '1024px',
  'xl': '1280px',
  '2xl': '1440px', // Modified from Tailwind default 1536px
}
```

---

## Design Standards

### No Colored Shadows
**Status:** 🔒 FIXED

Only neutral/black shadows allowed. Never use colored shadows.

```css
/* ✅ Allowed */
box-shadow: 0 4px 6px rgb(0 0 0 / 0.1);

/* ❌ Forbidden */
box-shadow: 0 4px 6px rgb(59 130 246 / 0.5);
```

---

### Component Naming
**Status:** 🔒 FIXED

All custom components prefixed with `|UXUIDC|`.

```
components/|UXUIDC|/
lib/|UXUIDC|/
styles/|UXUIDC|/
```

---

### Image Placeholders
**Status:** 🔒 FIXED

Use outlined div placeholders during development:

```tsx
<div className="border-2 border-dashed border-gray-300 bg-gray-50">
  <span className="text-gray-400">Image</span>
</div>
```

---

## Animation Standards

### GSAP Required
**Status:** 🔒 FIXED

GSAP is the standard animation library. Required plugins:
- ScrollTrigger
- ScrollToPlugin

---

### Standard Animation Components
**Status:** 🔒 FIXED

| Component | Purpose |
|-----------|---------|
| |UXUIDC|FadeInScroll | Fade in on scroll |
| |UXUIDC|StaggerAnimation | Staggered reveal |
| |UXUIDC|ParallaxEffect | Parallax scrolling |
| |UXUIDC|AnnouncementBar | Horizontal scroll |
| |UXUIDC|VerticalImageScroll | Vertical image scroll |

---

### Animation Performance Rules
**Status:** 🔒 FIXED

- Animate only `transform` and `opacity`
- Use `will-change` sparingly
- Never animate layout properties
- Cleanup in useEffect return
- Respect `prefers-reduced-motion`

---

## Typography Standards

### Minimum Font Size
**Status:** 🔒 FIXED

16px minimum for body text (accessibility requirement).

---

### Fluid Typography
**Status:** 🔒 FIXED

Use clamp() for responsive typography:

```css
h1: clamp(2rem, 5vw, 3.5rem);
h2: clamp(1.5rem, 4vw, 2.5rem);
p: clamp(1rem, 2vw, 1.125rem);
```

---

## Accessibility Standards

### WCAG 2.1 AA
**Status:** 🔒 FIXED

Minimum compliance level for all projects.

**Requirements:**
- Semantic HTML
- ARIA labels
- Keyboard navigation
- 4.5:1 color contrast (normal text)
- 3:1 color contrast (large text)
- Visible focus indicators
- Skip to main content link

---

## Legal Standards

### Required Pages
**Status:** 🔒 FIXED

Every project must include:

| Page | Path |
|------|------|
| Privacy Policy | /privacy |
| Terms of Service | /terms |
| Cookie Policy | /cookies |
| Accessibility Statement | /accessibility |

---

### Cookie Consent
**Status:** 🔒 FIXED

|UXUIDC|CookieConsent component required with:
- Granular consent categories
- Equal prominence Accept/Reject
- No dark patterns
- GPC signal respected

---

### Industry Legal Research
**Status:** 🔒 FIXED

Before creating legal pages, AI must search:
- `[industry] privacy policy requirements`
- `[industry] terms of service best practices`
- `[industry] legal compliance regulations`

---

## Privacy Standards

### Consent First
**Status:** 🔒 FIXED

- No tracking until explicit consent
- Granular consent by category
- Preference center always accessible
- GPC signal respected as opt out
- No pre-checked boxes
- No dark patterns

---

## SEO Standards

### Meta Keywords Obsolete
**Status:** 🔒 FIXED

Never include meta keywords tag. It is obsolete and ignored by search engines.

---

### Required Meta Tags
**Status:** 🔒 FIXED

- Title (60 chars, keyword first)
- Description (155-160 chars)
- Open Graph tags
- Twitter Card tags
- Schema.org structured data

---

## Industry Discovery

### Required First Step
**Status:** 🔒 FIXED

Before ANY design work, identify industry and complete research:

1. `[industry] website design best practices 2025`
2. `[industry] color palette typography standards`
3. `[industry] web design trends examples`
4. `[industry] privacy policy requirements 2025`
5. `[industry] terms of service best practices`
6. `[industry] legal compliance regulations`

---

## Required Components

### Navigation
**Status:** 🔒 FIXED

|UXUIDC|Navigation must include:
- GSAP animations
- Mobile hamburger
- Desktop horizontal
- Search functionality
- Keyboard accessible
- Scroll triggered behavior
- 1440px constraint

---

### Footer
**Status:** 🔒 FIXED

|UXUIDC|Footer must include:
- 1440px constraint
- Legal links section
- Social media links
- Copyright with "Built by UXUI Design Corp"
- Keyboard accessible

---

## Pre-Launch Requirements

### Lighthouse Scores
**Status:** 🔒 FIXED

90+ on all metrics required before launch.

---

### Core Web Vitals
**Status:** 🔒 FIXED

| Metric | Target |
|--------|--------|
| LCP | < 2.5s |
| FID | < 100ms |
| CLS | < 0.1 |
| FCP | < 1.8s |
| TTFB | < 600ms |

---

## Rocket Creative Specific

### No Hyphens
**Status:** 🔒 FIXED (Rocket Creative projects only)

No hyphens in any copy. Rewrite sentences to avoid.

---

## Deviation Process

If any 🔒 FIXED standard must be deviated from:

1. Document the deviation
2. Provide justification
3. Get approval from project lead
4. Log in decision-log.md
5. Note in project .mdc file

| Standard | Deviation | Justification | Approved by | Date |
|----------|-----------|---------------|-------------|------|
|          |           |               |             |      |

---

*UXUI Design Corp Fixed Standards v2.0*
*Last Updated: January 2026*
