# MDC Generator Instructions

This document explains how to convert completed intake questionnaires into `.mdc` rule files for Cursor/AI assisted development.

---

## Overview

The intake system consists of three questionnaires:

1. **PROJECT_INTAKE.md** → Generates `project-[name].mdc`
2. **DESIGN_SYSTEM_INTAKE.md** → Generates `design-system.mdc`
3. **CONTENT_COPY_INTAKE.md** → Generates `content-copy.mdc`

---

## How to Use

### Option 1: AI Generation (Recommended)

1. Complete the relevant intake questionnaire(s)
2. Provide the completed questionnaire to Claude/Cursor with this prompt:

```
Read the attached completed intake questionnaire and generate the corresponding .mdc file following the MDC Generator Instructions.

Output a complete, ready-to-use .mdc file that I can drop into my project's /rules folder.
```

3. Review the generated `.mdc` file
4. Save to your project's `/rules` folder

---

### Option 2: Manual Generation

Use the templates below, filling in values from your completed intake.

---

## Template: project-[name].mdc

```markdown
# project-[name].mdc
## [Project Name] Project Context

### PROJECT PURPOSE
[One paragraph from Section 1.2 of PROJECT_INTAKE.md]

### TARGET AUDIENCE
- Primary: [From Section 1.3]
- Secondary: [From Section 1.3]
- Technical level: [From Section 1.3]

### COMPETITIVE CONTEXT
[From Section 8.1 of PROJECT_INTAKE.md]
- Primary competitors: [List]
- Differentiation: [Description]

### KEY CONSTRAINTS
[Compile from Section 7.3 of PROJECT_INTAKE.md]
- [Constraint 1]
- [Constraint 2]
- [Constraint 3]

### TECH STACK
[From Section 2 of PROJECT_INTAKE.md]
- Framework: [Selection]
- Styling: [Selection]
- Data fetching: [Selection]
- Database: [Selection]
- CMS: [Selection]
- Auth: [Selection]
- Hosting: [Selection]

### INTEGRATIONS
[From Section 3 of PROJECT_INTAKE.md]
| Service | Purpose |
|---------|---------|
| [Name] | [Purpose] |

### CONTENT TYPES
[From Section 5.3 of CONTENT_COPY_INTAKE.md if completed]
- [Content type 1]
- [Content type 2]

### WORKFLOW NOTES
[Any project-specific workflows from Section 9]

### COMPLIANCE REQUIREMENTS
[From Section 5 of PROJECT_INTAKE.md]
- Regulations: [List]
- Data handling: [Summary]

### DEFINITION OF DONE
[From Section 10 of PROJECT_INTAKE.md]
- [ ] [Requirement 1]
- [ ] [Requirement 2]

### FORBIDDEN
[Compile forbidden items relevant to this project]
- [Forbidden 1]
- [Forbidden 2]
```

---

## Template: design-system.mdc

```markdown
# design-system.mdc
## Design System & Component Standards

### DESIGN SOURCE
- Tool: [From Section 1.1]
- File: [URL]
- Maintainer: [Name]

### COLOR SYSTEM

**Brand Colors**
- Primary: [hex] "[name]"
- Secondary: [hex] "[name]"
- Accent: [hex] "[name]"

**Semantic Colors**
| Token | Light | Dark |
|-------|-------|------|
| background-primary | [hex] | [hex] |
| background-secondary | [hex] | [hex] |
| text-primary | [hex] | [hex] |
| text-secondary | [hex] | [hex] |
| border-default | [hex] | [hex] |

**Feedback Colors**
- Success: [hex]
- Warning: [hex]
- Error: [hex]
- Info: [hex]

### TYPOGRAPHY

**Fonts**
- Primary: [name], [weights], [source]
- Secondary: [name], [weights], [source]
- Monospace: [name or "system"]

**Type Scale** (base: [size], ratio: [ratio])
| Token | Size | Line height | Weight |
|-------|------|-------------|--------|
| h1 | | | |
| h2 | | | |
| h3 | | | |
| body | | | |
| small | | | |

**Text Rules**
- Max line length: [characters]
- Link style: [description]

### SPACING

**Base unit:** [value]

**Scale**
| Token | Value |
|-------|-------|
| xs | |
| sm | |
| md | |
| lg | |
| xl | |

**Layout**
- Container max-width: [value]
- Container padding: [mobile] / [tablet] / [desktop]

### BREAKPOINTS
| Name | Value |
|------|-------|
| sm | |
| md | |
| lg | |
| xl | |

### COMPONENTS

**Library:** [name]
**Customization:** [approach]

**Border Radius**
- Default: [value]
- Scale: none / sm / md / lg / full

**Shadows**
- sm: [value]
- md: [value]
- lg: [value]

**Button Variants**
| Variant | Background | Text | Border |
|---------|------------|------|--------|
| primary | | | |
| secondary | | | |
| outline | | | |
| ghost | | | |

### ICONS
- Library: [name]
- Format: [SVG/font]
- Default size: [value]
- Stroke width: [value]

### MOTION
- Philosophy: [minimal/subtle/expressive]
- Respect reduced motion: YES
- Default duration: [value]
- Default easing: [value]

### DARK MODE
- Support: [yes/no/system/toggle]
- Implementation: [approach]

### FORBIDDEN
- [From questionnaire forbidden items]
- Mixing CSS methodologies
- Inline styles (except dynamic values)
- Colors outside defined tokens
- Typography outside defined scale
```

---

## Template: content-copy.mdc

```markdown
# content-copy.mdc
## Content & Copy Standards

### VOICE
[2-3 sentence summary from Section 1]

**Voice attributes:** [3-5 selected attributes]

**Never sound like:** [From Section 1.2]

### TONE BY CONTEXT
| Context | Tone |
|---------|------|
| Marketing | |
| Product UI | |
| Error messages | |
| Email | |
| Support | |

### WRITING STYLE

**Structure**
- Sentence style: [short/mixed/varied]
- Voice: [active preferred/required]
- Contractions: [use/avoid]

**Punctuation**
- Oxford comma: [always/never]
- Exclamation points: [sparingly/avoid]
- Dashes: [em/en/hyphens only/avoid]
- Hyphens in copy: [standard/minimize/forbidden]

**Formatting**
- Heading case: [sentence/title]
- Numbers: [spell out rule]

### TERMINOLOGY

**Required terms**
| Term | Usage |
|------|-------|
| | |

**Forbidden words**
- [Word]: use "[alternative]" instead
- [Word]: use "[alternative]" instead

**Product terminology**
- Product name: [exact spelling]
- User term: [users/customers/members/etc.]

### SEO REQUIREMENTS
[If applicable from Section 5]

**Structure**
- H1: One per page, primary keyword, under 60 chars
- Meta title: [format]
- Meta description: Under 160 chars, keyword, CTA

**Keywords**
- Primary: [list]
- Secondary: [list]

### ACCESSIBILITY
- Reading level: [grade]
- Alt text: Required, describe function
- Inclusive language: [requirements]

### LEGAL
[If applicable from Section 7]
- Disclaimers: [requirements]
- Claims policy: [restrictions]
- Competitor mentions: [policy]

### FORBIDDEN
- [From questionnaire]
- Hyphens (if selected)
- Passive voice (if required)
- [Forbidden words list]
- [Clichés list]
```

---

## Generation Checklist

Before finalizing any `.mdc` file, verify:

- [ ] All REQUIRED sections have content
- [ ] All FORBIDDEN sections are populated
- [ ] No placeholder text remains
- [ ] Values are specific, not generic
- [ ] File follows the rule hierarchy (stricter wins)
- [ ] File is consistent with other project `.mdc` files

---

## File Naming

| Intake | Output file | Location |
|--------|-------------|----------|
| PROJECT_INTAKE.md | `project-[codename].mdc` | `/rules/` |
| DESIGN_SYSTEM_INTAKE.md | `design-system.mdc` | `/rules/` |
| CONTENT_COPY_INTAKE.md | `content-copy.mdc` | `/rules/` |

**Naming rules:**
- Lowercase
- Hyphens between words
- `.mdc` extension (not `.md`)

---

## Updating Existing Files

When project requirements change:

1. Update the relevant intake questionnaire
2. Regenerate the `.mdc` file
3. Log the change in `/docs/decision-log.md`
4. Commit with message: `docs: update [filename] - [reason]`

---

## Quick Start Prompt

Copy this prompt to quickly generate all three files from completed intakes:

```
I've completed the following intake questionnaires:
- PROJECT_INTAKE.md
- DESIGN_SYSTEM_INTAKE.md  
- CONTENT_COPY_INTAKE.md

Generate the corresponding .mdc files:
1. project-[name].mdc
2. design-system.mdc
3. content-copy.mdc

Follow the MDC Generator Instructions templates. Output complete, ready-to-use files.
```

---

*These templates are starting points. Customize based on project complexity.*
