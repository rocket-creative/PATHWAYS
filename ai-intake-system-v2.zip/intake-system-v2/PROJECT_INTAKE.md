# Project Intake Questionnaire
## UXUI Design Corp Edition

Complete this questionnaire before starting any new project. Your answers generate `.mdc` rule files for Cursor/AI assisted development.

**Note:** Items marked with 🔒 are UXUI Design Corp standards (non-negotiable). Items marked with 💡 are suggested defaults.

---

## Section 0: Industry Discovery

🔒 **CRITICAL: This must be completed FIRST before any design work.**

### 0.1 Industry Identification

**What industry is this project for?**
> [ ] Biotech/Life Sciences
> [ ] Healthcare/Medical
> [ ] Luxury Services/Hospitality
> [ ] Financial Services
> [ ] Legal
> [ ] E-commerce/Retail
> [ ] SaaS/Technology
> [ ] Real Estate
> [ ] Creative/Media
> [ ] Education
> [ ] Nonprofit
> [ ] Other: _______________

---

### 0.2 Industry Research Checklist

🔒 **REQUIRED: AI must complete these searches before design begins:**

- [ ] `[industry] website design best practices 2025`
- [ ] `[industry] color palette typography standards`
- [ ] `[industry] web design trends examples`
- [ ] `[industry] privacy policy requirements 2025`
- [ ] `[industry] terms of service best practices`
- [ ] `[industry] legal compliance regulations`

**Research notes:**
> 

---

## Section 1: Project Identity

### 1.1 Basic Information

**Project name:**
> 

**Project codename (if different):**
> 

**Client name:**
> 

**Client contact(s):**

| Name | Role | Email | Decision authority |
|------|------|-------|-------------------|
|      |      |       |                   |

---

### 1.2 Project Purpose

**One sentence description:**
> 

**Problem being solved:**
> 

**Success criteria (2-3 measurable outcomes):**

1. 
2. 
3. 

---

### 1.3 Target Audience

**Primary users:**
> 

**Secondary users:**
> 

**User technical sophistication:**
> [ ] Non-technical
> [ ] Semi-technical
> [ ] Technical
> [ ] Mixed

---

## Section 2: Technical Foundation

### 2.1 Framework

**Framework:**
> [ ] Next.js (App Router) 💡 DEFAULT
> [ ] Next.js (Pages Router)
> [ ] Angular (only if Next.js not viable)
> [ ] React (Vite)
> [ ] Astro
> [ ] Webflow (CMS projects)
> [ ] Other: _______________

**If not Next.js App Router, explain:**
> 

**Language:**
> [ ] TypeScript (strict) 🔒 DEFAULT
> [ ] TypeScript (standard)
> [ ] JavaScript

---

### 2.2 Rendering Strategy

**Primary rendering:**
> [ ] Static (SSG) 💡 for marketing/content sites
> [ ] ISR (Incremental Static Regeneration)
> [ ] SSR (Server Side Rendering)
> [ ] CSR (Client Side)
> [ ] Hybrid

🔒 **FIXED: Page type rendering rules:**

| Page Type | Rendering | Rationale |
|-----------|-----------|-----------|
| Homepage | Static (ISR) | SEO critical |
| About/Services | Static | Rarely changes |
| Blog Posts | Static (ISR) | SEO critical |
| Product Pages | Static (ISR) | SEO important |
| Search Results | SSR | Query dependent |
| User Dashboard | SSR/CSR | Personalized |
| Admin Panel | CSR | Interactive |
| Terms/Privacy | Static | Legal, SEO |

---

### 2.3 Styling

**CSS approach:**
> [ ] Tailwind CSS 💡
> [ ] CSS Modules
> [ ] Styled Components
> [ ] Sass/SCSS
> [ ] Other: _______________

🔒 **FIXED: Tailwind config must include:**
```javascript
screens: {
  '2xl': '1440px', // Modified from default
},
extend: {
  maxWidth: {
    'site': '1440px',
  }
}
```

**Component library:**
> [ ] shadcn/ui 💡
> [ ] Radix UI
> [ ] Custom only
> [ ] Other: _______________

---

### 2.4 Data & API

**Data fetching:**
> [ ] Server components (fetch in RSC) 💡
> [ ] React Query
> [ ] SWR
> [ ] tRPC
> [ ] Other: _______________

**Database:**
> [ ] PostgreSQL
> [ ] Supabase
> [ ] Firebase
> [ ] None (static/CMS)
> [ ] Other: _______________

**CMS:**
> [ ] Webflow
> [ ] Sanity
> [ ] Contentful
> [ ] None
> [ ] Other: _______________

---

### 2.5 Authentication

**Auth required?**
> [ ] Yes
> [ ] No
> [ ] Phase 2

**Auth provider:**
> [ ] NextAuth.js
> [ ] Clerk
> [ ] Supabase Auth
> [ ] Other: _______________

---

### 2.6 Hosting

**Platform:**
> [ ] Vercel 💡
> [ ] Netlify
> [ ] AWS
> [ ] Other: _______________

**Environments:**
> [ ] Production only
> [ ] Production + Staging 💡
> [ ] Production + Staging + Dev

**Domain:**
> Production: 
> Staging: 

---

## Section 3: Integrations

### 3.1 Analytics

**Analytics platform:**
> [ ] Google Analytics 4
> [ ] Plausible 💡 (privacy friendly)
> [ ] Fathom
> [ ] None
> [ ] Other: _______________

🔒 **FIXED: All analytics must be consent gated.**

**Additional tracking:**
> [ ] Meta Pixel
> [ ] Google Ads
> [ ] LinkedIn Insight
> [ ] None
> [ ] Other: _______________

---

### 3.2 External Services

| Service | Purpose | Consent required? |
|---------|---------|-------------------|
|         |         |                   |
|         |         |                   |

**Payment processing:**
> [ ] Stripe 💡
> [ ] PayPal
> [ ] None
> [ ] Other: _______________

**Email service:**
> [ ] Resend 💡
> [ ] SendGrid
> [ ] Postmark
> [ ] None
> [ ] Other: _______________

---

## Section 4: Design Standards

🔒 **FIXED: UXUI Design Corp design standards apply to all projects.**

### 4.1 Layout Constraints

🔒 **FIXED: 1440px maximum content width.**

- Content constrained to 1440px for optimal readability
- Centers on larger displays (1920px+, 4K)
- Never stretches full width

**Testing required:**
- [ ] 1920x1080 display
- [ ] 2560x1440 display  
- [ ] 3840x2160 (4K) display

---

### 4.2 Design Principles

🔒 **FIXED: UXUI Design Corp design principles:**

- Classy but impressive: Sophisticated with memorable interactions
- Mobile first: Every decision starts with mobile
- Accessible: WCAG 2.1 AA minimum
- Performance: Animations at 60fps
- No colored drop shadows: Neutral shadows only
- 1440px maximum: Content constrained

---

### 4.3 Component Naming

🔒 **FIXED: |UXUIDC| prefix for all custom components.**

```
components/|UXUIDC|/
lib/|UXUIDC|/
styles/|UXUIDC|/
```

---

### 4.4 Animation

🔒 **FIXED: GSAP for all animations.**

Required animation components:
- |UXUIDC|FadeInScroll
- |UXUIDC|StaggerAnimation
- |UXUIDC|ParallaxEffect
- |UXUIDC|AnnouncementBar
- |UXUIDC|VerticalImageScroll

Performance rules:
- Animate only transform and opacity
- Cleanup in useEffect return
- Respect prefers-reduced-motion

---

## Section 5: Content & Copy

### 5.1 Voice

**Brand voice attributes (select 3-5):**
> [ ] Professional
> [ ] Friendly
> [ ] Authoritative
> [ ] Technical
> [ ] Warm
> [ ] Direct
> [ ] Sophisticated
> [ ] Other: _______________

---

### 5.2 Copy Standards

🔒 **FIXED (if applicable): No hyphens in copy.**
> [ ] Yes, no hyphens (Rocket Creative standard)
> [ ] Standard hyphen usage allowed

**Other copy rules:**
> 

---

### 5.3 SEO Priority

**SEO importance:**
> [ ] Critical
> [ ] High
> [ ] Medium
> [ ] Low/N/A

🔒 **FIXED: Meta keywords tag is OBSOLETE. Never include.**

**Primary keywords:**
- 
- 
- 

---

## Section 6: Compliance

### 6.1 Privacy

**Applicable regulations:**
> [ ] GDPR
> [ ] CCPA/CPRA
> [ ] HIPAA
> [ ] None specifically
> [ ] Other: _______________

🔒 **FIXED: Consent first privacy.**
- No tracking until explicit consent
- Granular consent by category
- GPC signal respected
- No dark patterns

---

### 6.2 Legal Pages

🔒 **FIXED: Required for every project:**

| Page | Path | Status |
|------|------|--------|
| Privacy Policy | /privacy | [ ] Created |
| Terms of Service | /terms | [ ] Created |
| Cookie Policy | /cookies | [ ] Created |
| Accessibility | /accessibility | [ ] Created |

🔒 **FIXED: Legal pages must include industry specific clauses.**

After industry identification, AI must research:
- `[industry] privacy policy requirements`
- `[industry] terms of service best practices`
- `[industry] legal compliance regulations`

---

### 6.3 Accessibility

🔒 **FIXED: WCAG 2.1 AA minimum.**

- Semantic HTML required
- ARIA labels required
- Keyboard navigation required
- Color contrast 4.5:1 minimum
- Focus indicators visible

---

## Section 7: Constraints

### 7.1 Timeline

**Start date:**
> 

**Target launch:**
> 

**Hard deadline?**
> [ ] Yes
> [ ] Flexible

---

### 7.2 Budget

**Budget range:**
> [ ] Under $10K
> [ ] $10K-$25K
> [ ] $25K-$50K
> [ ] $50K-$100K
> [ ] $100K+
> [ ] Retainer

---

### 7.3 Known Risks

> 

---

## Section 8: Competitors & References

### 8.1 Competitors

| Competitor | URL | Notes |
|------------|-----|-------|
|            |     |       |
|            |     |       |

---

### 8.2 Design References

| URL | What to reference |
|-----|-------------------|
|     |                   |
|     |                   |

---

## Section 9: Git & Workflow

### 9.1 Branching

**Strategy:**
> [ ] Simple (feature → main) 💡
> [ ] Gitflow
> [ ] Trunk based

**Commit format:**
> [ ] Conventional commits 💡 (feat:, fix:, etc.)
> [ ] Free form
> [ ] Ticket number required

---

### 9.2 Communication

**Primary channel:**
> [ ] Slack
> [ ] Email
> [ ] Other: _______________

**Meeting cadence:**
> [ ] Weekly 💡
> [ ] Bi-weekly
> [ ] As needed

---

## Section 10: Definition of Done

### 10.1 Pre-Launch Checklist

🔒 **FIXED: All items required before launch:**

**Build:**
- [ ] Build passes
- [ ] Lint passes
- [ ] Tests pass (if applicable)

**Design:**
- [ ] 1440px constraint verified
- [ ] Large display testing complete
- [ ] No colored shadows
- [ ] |UXUIDC| naming used

**Accessibility:**
- [ ] WCAG 2.1 AA verified
- [ ] Keyboard navigation tested
- [ ] Screen reader tested

**Legal:**
- [ ] Privacy Policy created
- [ ] Terms of Service created
- [ ] Cookie Policy created
- [ ] Accessibility Statement created
- [ ] Cookie consent working
- [ ] Industry specific clauses included

**SEO:**
- [ ] Meta tags complete (no keywords tag)
- [ ] Schema.org markup added
- [ ] OG images created (1200x630)
- [ ] Sitemap generated
- [ ] robots.txt configured

**Performance:**
- [ ] Lighthouse 90+ all metrics
- [ ] Core Web Vitals passing
- [ ] Images optimized

**Final:**
- [ ] Client sign off received
- [ ] DNS configured
- [ ] SSL active

---

### 10.2 Post-Launch

**Warranty:**
> [ ] 30 days
> [ ] 60 days 💡
> [ ] 90 days

**Maintenance:**
> [ ] Retainer
> [ ] Ad hoc
> [ ] Handed off

---

## Notes

> 

---

## Intake Completed

**Completed by:**
> 

**Date:**
> 

**Industry:**
> 

**Client approved:**
> [ ] Yes
> [ ] Pending

---

*UXUI Design Corp standards embedded. Version 2.0*
