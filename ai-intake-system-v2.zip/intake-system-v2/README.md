# AI Project Intake System
## UXUI Design Corp Edition

A comprehensive questionnaire system for capturing project context upfront, enabling faster AI assisted development with Cursor.

**This edition includes embedded UXUI Design Corp standards:**
- 🔒 Fixed standards that never change (1440px max, no colored shadows, GSAP, etc.)
- 💡 Suggested defaults based on best practices
- Industry specific design guidance (biotech, luxury, financial, legal)

---

## The Problem

Every new Cursor session starts from scratch. You waste time re-explaining:
- What the project is
- What the tech stack is
- What the design system looks like
- What the copy rules are
- What's forbidden

This intake system captures everything once, then generates `.mdc` rule files that Cursor reads automatically.

---

## How It Works

```
┌─────────────────────────────────────────────────────────────┐
│                    INTAKE QUESTIONNAIRES                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   PROJECT_INTAKE.md         Complete once per project        │
│   ─────────────────         ↓                               │
│                             project-[name].mdc               │
│                                                              │
│   DESIGN_SYSTEM_INTAKE.md   Complete once per project        │
│   ───────────────────────   ↓                               │
│                             design-system.mdc                │
│                                                              │
│   CONTENT_COPY_INTAKE.md    Complete once per project        │
│   ──────────────────────    ↓                               │
│                             content-copy.mdc                 │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                    MDC_GENERATOR_INSTRUCTIONS.md             │
│                    (Templates + prompts for generation)      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      YOUR PROJECT REPO                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   /rules                                                     │
│     ├── core-stack.mdc          (from cursor-constitution)  │
│     ├── coding-style.mdc        (from cursor-constitution)  │
│     ├── privacy-compliance.mdc  (from cursor-constitution)  │
│     ├── accessibility.mdc       (from cursor-constitution)  │
│     ├── security.mdc            (from cursor-constitution)  │
│     ├── testing-release.mdc     (from cursor-constitution)  │
│     ├── observability.mdc       (from cursor-constitution)  │
│     ├── api-patterns.mdc        (from cursor-constitution)  │
│     ├── performance.mdc         (from cursor-constitution)  │
│     ├── git-workflow.mdc        (from cursor-constitution)  │
│     │                                                        │
│     ├── project-itl.mdc         ← FROM INTAKE               │
│     ├── design-system.mdc       ← FROM INTAKE               │
│     └── content-copy.mdc        ← FROM INTAKE               │
│                                                              │
│   READ_THIS_FIRST.mdc                                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                         CURSOR/AI                            │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   "Read READ_THIS_FIRST.mdc, then all .mdc files..."        │
│                                                              │
│   AI now knows:                                              │
│   ✓ Project purpose and audience                            │
│   ✓ Tech stack decisions                                    │
│   ✓ Design tokens and components                            │
│   ✓ Copy rules and forbidden words                          │
│   ✓ All constraints and requirements                        │
│                                                              │
│   No more re-explaining every session.                      │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## Files in This System

| File | Purpose | When to complete |
|------|---------|------------------|
| `PROJECT_INTAKE.md` | Captures everything about the project: purpose, stack, integrations, constraints | Once per project (start of engagement) |
| `DESIGN_SYSTEM_INTAKE.md` | Captures design tokens, typography, colors, components | Once per project (when design is ready) |
| `CONTENT_COPY_INTAKE.md` | Captures voice, tone, terminology, SEO, forbidden words | Once per project (when brand is defined) |
| `MDC_GENERATOR_INSTRUCTIONS.md` | Templates and prompts for converting intakes to `.mdc` files | Reference document |

---

## Quick Start

### Step 1: Complete the intakes

Start with `PROJECT_INTAKE.md`. This is the most important one.

Add `DESIGN_SYSTEM_INTAKE.md` when you have design specs.

Add `CONTENT_COPY_INTAKE.md` when you have brand/copy guidelines.

### Step 2: Generate the .mdc files

**Option A: Use AI**

```
Here is my completed PROJECT_INTAKE.md:
[paste completed questionnaire]

Generate a project-[name].mdc file following the MDC Generator Instructions template.
```

**Option B: Manual**

Use the templates in `MDC_GENERATOR_INSTRUCTIONS.md` to create the files yourself.

### Step 3: Add to your project

1. Copy the base cursor-constitution files to your project root
2. Add your generated `.mdc` files to `/rules`
3. Start every Cursor session with:

```
Read READ_THIS_FIRST.mdc, then all .mdc files in /rules and /docs. Proceed with [task].
```

---

## Intake Coverage

### PROJECT_INTAKE.md covers:

**Section 1: Project Identity**
- Basic info (name, client, industry)
- Purpose and success criteria
- Target audience

**Section 2: Technical Foundation**
- Framework and language
- Styling approach
- Data fetching and API
- Authentication
- Hosting and deployment

**Section 3: Integrations**
- Analytics and tracking
- External services
- Payment, email, storage, search

**Section 4: Content & Copy**
- Voice and tone (summary)
- Copy standards (summary)
- SEO requirements (summary)

**Section 5: Compliance & Security**
- Privacy regulations
- Data collection
- Security requirements

**Section 6: Accessibility**
- Compliance level
- Testing approach

**Section 7: Project Constraints**
- Timeline
- Budget
- Known risks

**Section 8: Reference & Inspiration**
- Competitors
- Design references
- Existing assets

**Section 9: Workflow & Process**
- Git workflow
- Communication
- Documentation

**Section 10: Definition of Done**
- Launch checklist
- Post-launch requirements

---

### DESIGN_SYSTEM_INTAKE.md covers:

**Section 1: Foundation**
- Design source of truth
- Brand guidelines

**Section 2: Color System**
- Brand colors
- Semantic colors
- Feedback colors
- Accessibility

**Section 3: Typography**
- Font families
- Type scale
- Text styling

**Section 4: Spacing System**
- Spacing scale
- Layout spacing

**Section 5: Layout & Grid**
- Grid system
- Breakpoints

**Section 6: Components**
- Component library
- Border radius
- Shadows
- Common components

**Section 7: Motion & Animation**
- Animation principles
- Timing
- Common animations

**Section 8: Icons**
- Icon system
- Icon sizing

**Section 9: Dark Mode**
- Strategy
- Color overrides

**Section 10: Documentation**
- Where docs live
- Contribution guidelines

---

### CONTENT_COPY_INTAKE.md covers:

**Section 1: Brand Voice**
- Voice attributes
- Voice description
- Voice inspiration

**Section 2: Tone Variations**
- Tone by context
- Audience tone mapping

**Section 3: Writing Style**
- Grammar and punctuation
- Formatting preferences
- Punctuation and symbols

**Section 4: Terminology**
- Industry terminology
- Product terminology
- Forbidden words
- Preferred alternatives

**Section 5: SEO & Content Structure**
- SEO priority
- Content structure
- Content types

**Section 6: Accessibility & Inclusion**
- Inclusive language
- Reading level
- Alt text

**Section 7: Legal & Compliance**
- Required disclaimers
- Claims and substantiation
- Competitor mentions

**Section 8: Content Workflow**
- Approvals
- Style guide
- Localization

**Section 9: Examples**
- Good examples
- Bad examples

**Section 10: Quick Reference**
- Summary generation

---

## Tips for Faster Intake

1. **Don't fill everything** — Skip sections that don't apply. Empty sections won't generate rules.

2. **Start with PROJECT_INTAKE.md** — This gives 80% of the value. Add others as needed.

3. **Copy from existing docs** — Pull from brand guidelines, design specs, past briefs.

4. **Use AI to help** — Paste a design file screenshot and ask AI to extract the tokens.

5. **Iterate** — Start rough, refine as the project progresses. Update the `.mdc` files when decisions change.

---

## Example: Generating project-itl.mdc

**Input (excerpt from completed intake):**

```
Project name: ITL Content System
Client: Ingenious Targeting Laboratory  
Industry: Biotech/Life Sciences
Purpose: Content system for genetargeting.com rebuild
Target audience: Academic researchers, lab managers
Framework: Webflow (CMS)
Copy rules: No hyphens, authoritative tone
```

**Output:**

```markdown
# project-itl.mdc
## Ingenious Targeting Laboratory Project Context

### PROJECT PURPOSE
Content system for genetargeting.com website rebuild. Generate technically authoritative, SEO optimized pages for mouse model services.

### TARGET AUDIENCE
- Primary: Academic researchers, lab managers
- Secondary: Biotech/pharma procurement teams
- Technical level: Highly technical

### KEY CONSTRAINTS
- Content must be scientifically accurate
- No hyphens in any copy
- Authoritative peer tone, not sales pitch

### TECH STACK
- CMS: Webflow
- Integration: Existing ITL backend systems

### FORBIDDEN
- Hyphens in copy
- Marketing fluff without substantiation
- Jargon without explanation
```

---

## Maintenance

**When to update intakes:**
- Major scope change
- New integration added
- Design system update
- Brand refresh
- Compliance requirement change

**How to update:**
1. Edit the relevant intake questionnaire
2. Regenerate the `.mdc` file
3. Log in `/docs/decision-log.md`
4. Commit: `docs: update [file] - [reason]`

---

## File Structure After Setup

```
your-project/
├── READ_THIS_FIRST.mdc
├── README.md
├── rules/
│   ├── core-stack.mdc
│   ├── coding-style.mdc
│   ├── privacy-compliance.mdc
│   ├── accessibility.mdc
│   ├── security.mdc
│   ├── testing-release.mdc
│   ├── observability.mdc
│   ├── api-patterns.mdc
│   ├── performance.mdc
│   ├── git-workflow.mdc
│   ├── content-copy.mdc          ← Generated from intake
│   ├── design-system.mdc         ← Generated from intake
│   └── project-[name].mdc        ← Generated from intake
├── docs/
│   ├── AI_CHANGELOG_TEMPLATE.mdc
│   ├── DECISION_LOG.mdc
│   └── decision-log.md
└── [project files...]
```

---

## Support

Questions? Issues? 

- Review the templates in `MDC_GENERATOR_INSTRUCTIONS.md`
- Check the cursor-constitution `README.md` for base rules
- Update intakes and regenerate when things change

---

*Built for Rocket Creative LLC projects. Adapt as needed.*
